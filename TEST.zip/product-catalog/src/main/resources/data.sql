



insert into PRODUCT(id,name,price,can_buy,make_date,image,description) values(1,'Laptop',198000,true,'2019-05-19','images/Laptop.png','New Mac pro')
insert into PRODUCT(id,name,price,can_buy,make_date,image,description) values(2,'Mobile',1800,true,'2019-05-19','images/Mobile.png','New pro')

