package com.capg.demo.service;

import java.util.List;

import com.capg.demo.model.Product;

public interface IProductService {
	public List<Product> getAllProducts();
}
