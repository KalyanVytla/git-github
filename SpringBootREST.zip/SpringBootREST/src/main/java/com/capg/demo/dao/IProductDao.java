package com.capg.demo.dao;

import java.util.List;

import com.capg.demo.model.Product;

public interface IProductDao {
	
	public List<Product> getAllProducts();

}
