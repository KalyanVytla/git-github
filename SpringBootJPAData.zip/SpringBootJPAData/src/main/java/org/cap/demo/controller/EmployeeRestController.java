package org.cap.demo.controller;

import java.util.List;

import org.cap.demo.model.Employee;
import org.cap.demo.service.IEmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v2")
public class EmployeeRestController {
	
	@Autowired
	private IEmployeeService employeeService;
	
	
	@PostMapping("/employees")
	public ResponseEntity<List<Employee>> createEmployee(
		@RequestBody Employee employee){
		
		List<Employee> employees= employeeService.createEmployee(employee);
		if(employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee Details not Avilable",
						HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

	
	@GetMapping("/employees")
	public ResponseEntity<List<Employee>> getAllEmployees(){
		
		List<Employee> employees= employeeService.getAllEmployees();
		if(employees.isEmpty()) {
			return new ResponseEntity("Sorry! Employee Details not Avilable",
						HttpStatus.NOT_FOUND);
		}
		
		
		return new ResponseEntity<List<Employee>>(employees, HttpStatus.OK);
	}

}
