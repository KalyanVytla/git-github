package com.capg.demo.dao;

import java.util.List;

import com.capg.demo.model.Product;

public interface IProductDao {
	
	public List<Product> getAllProducts();
	public Product findProduct(int productId);
	public List<Product> deleteProduct(int productId);
	public List<Product> createProduct(Product product);

}
